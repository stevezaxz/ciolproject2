<?php

class regc extends CI_Controller {

    public function index() {
        $data = array(
            'title' => 'Registration'
        );
        $this->load->view('header', $data);
        $this->load->view('registration');
    }

}
