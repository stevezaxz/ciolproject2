<html>
    <head>
	
        <title><?php echo $title; ?></title>
       <!-- < ?php echo link_tag("public/bootstrap/css/simplex.css", "stylesheet", "text/css"); ?> -->
	    <?php echo link_tag("public/bootstrap/css/ubuntu.css", "stylesheet", "text/css"); ?> 
	    <!-- <?php echo link_tag("public/bootstrap/css/superhero.css", "stylesheet", "text/css"); ?> -->		
		<!--< ?php echo link_tag("public/bootstrap/css/flatly.css", "stylesheet", "text/css"); ?>-->
        <script src="<?php echo base_url('public/jquery.min.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo base_url('public/bootstrap/js/bootstrap.min.js'); ?>" type="text/javascript"></script>

    </head>
    <body>
        <div class="container-fluid">
            <div class="row">
                
            
                <nav class="navbar navbar-default navbar-fixed-top ">
				
                        <div class="container-fluid">
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
                                <div class="navbar-header">    

                                    <a href="<?php echo site_url('/'); ?>" class="navbar-brand">Logo</a>
                                </div>
                                <ul class="nav navbar-nav navbar-right">
                                    <li class ="active"><a href="<?php echo site_url('regc/index'); ?>">Register Now!</a></li>
                                    <li><a href="<?php echo site_url('loginc/login'); ?>">Login</a></li>
                                    <li><a href="<?php echo site_url('aboutc/test');?>">About Us</a></li>
                                    <li><a href="<?php echo site_url('supplierc/supplierprofile');?>">Contact</a></li>
                                </ul>
                            </div>
				
                        </div>
                    </nav>
                
                
                
                
                <div class="col-md-2">
                                                                    
                </div>
                
                <div class="col-md-8">

<!--                    <nav class="navbar navbar-default navbar-fixed-top ">
				
                        <div class="container-fluid">
                            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
                                <div class="navbar-header">    

                                    <a href="<?php echo site_url('/'); ?>" class="navbar-brand">Logo</a>
                                </div>
                                <ul class="nav navbar-nav navbar-right">
                                    <li class ="active"><a href="<?php echo site_url('regc/index'); ?>">Register Now!</a></li>
                                    <li><a href="<?php echo site_url('loginc/login'); ?>">Login</a></li>
                                    <li><a href="<?php echo site_url('aboutc/test');?>">About Us</a></li>
                                    <li><a href="<?php echo site_url('supplierc/supplierprofile');?>">Contact</a></li>
                                </ul>
                            </div>
				
                        </div>
                    </nav>-->


<br>
<br>
<br>
<br>