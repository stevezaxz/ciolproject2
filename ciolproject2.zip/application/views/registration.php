<h3>Supplier Netzwerk Registration form</h3>

<div class="container">
    <div class="stepwizard">
        <div class="stepwizard-row setup-panel">
            <div class="stepwizard-step">
                <a href="#step-1" type="button" class="btn btn-primary btn-circle">1</a>
                <p>Step 1</p>
            </div>
            <div class="stepwizard-step">
                <a href="#step-2" type="button" class="btn btn-default btn-circle" disabled="disabled">2</a>
                <p>Step 2</p>
            </div>
            <div class="stepwizard-step">
                <a href="#step-3" type="button" class="btn btn-default btn-circle" disabled="disabled">3</a>
                <p>Step 3</p>
            </div>
        </div>
    </div>
    <form role="form">
        <div class="row setup-content" id="step-1">
            <div class="col-xs-12">
                <div class="col-md-12">
                    <div class="form-horizontal" role="form">
                        <fieldset>
                            <!-- Form Name -->
                            <h4>Company Details</h4>
                            <!-- Text input-->
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Registrant's Name</label>
                                <div class="col-md-10">
                                    <input required type="text" id="registrants_name" class="form-control" >
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Username</label>
                                <div class="col-md-10">
                                    <input required type="text" id="username" class="form-control" >
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Password</label>
                                <div class="col-md-10">
                                    <input required type="password" id="password" class="form-control" >
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput"> Retype-Password</label>
                                <div class="col-md-10">
                                    <input required type="password" id="password" class="form-control" >
                                </div>
                            </div>

                            <!-- Text input-->
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Business Trade Name</label>
                                <div class="col-md-10">
                                    <input required type="text" id="business_trade_name" class="form-control" >
                                </div>
                            </div>

                            <!-- Text input-->
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">TIN No.</label>
                                <div class="col-md-10">
                                    <input required type="text" id="tin_no" class="form-control" >
                                </div>
                            </div>

                            <!-- Text input-->
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">BIR Registration No.</label>
                                <div class="col-md-4">
                                    <input required type="text" id="bir" class="form-control" >
                                </div>

                                <!--                    <label class="col-md-2 control-label" for="textinput">Website</label>
                                                    <div class="col-md-4">
                                                        <input type="text" placeholder="Post Code" class="form-control">
                                                    </div>-->
                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Overview/ Brief History</label>
                                <div class="col-md-10">
            <!--                        <input type="textarea" placeholder="City" class="form-control" row='5' col='5'>-->
                                    <textarea required class='form-control'  id="overview_history" cols="10" rows="10"></textarea>
                                </div>
                            </div>

                        </fieldset>
                    </div>
                    <div class="form-horizontal" role="form">
                        <fieldset>
                            <!-- Form Name -->
                            <h4>Contact Person</h4>
                            <!-- Text input-->
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput"><h4>Sales</h4></label>
                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Name</label>
                                <div class="col-md-10">
                                    <input type="text" id="contact_person_sales_name" class="form-control" >
                                </div>
                            </div>

                            <!-- Text input-->
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Telephone No.</label>
                                <div class="col-md-10">
                                    <input type="text" id="contact_person_sales_telephone" class="form-control" >
                                </div>
                            </div>

                            <!-- Text input-->
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Fax no.</label>
                                <div class="col-md-10">
                                    <input type="text" id="contact_person_sales_fax" class="form-control" >
                                </div>
                            </div>

                            <!-- Text input-->
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Email</label>
                                <div class="col-md-4">
                                    <input type="text" id="contact_person_sales_email" class="form-control" >
                                </div>


                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Mobile 1</label>
                                <div class="col-md-4">
                                    <input type="text" id="contact_person_sales_mobile_1" class="form-control" >
                                </div>

                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Mobile 2</label>
                                <div class="col-md-4">
                                    <input type="text" id="contact_person_sales_mobile_2" class="form-control"/>
                                </div>

                            </div>

                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput"><h4>Procurement</h4></label>
                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Name</label>
                                <div class="col-md-10">
                                    <input type="text" id="contact_person_procurement_name" class="form-control" >
                                </div>
                            </div>

                            <!-- Text input-->
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Telephone No.</label>
                                <div class="col-md-10">
                                    <input type="text" id="contact_person_procurement_telephone" class="form-control" >
                                </div>
                            </div>

                            <!-- Text input-->
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Fax no.</label>
                                <div class="col-md-10">
                                    <input type="text" id="contact_person_procurement_fax" class="form-control" >
                                </div>
                            </div>

                            <!-- Text input-->
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Email</label>
                                <div class="col-md-4">
                                    <input type="text" id="contact_person_procurement_email" class="form-control" >
                                </div>


                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Mobile 1</label>
                                <div class="col-md-4">
                                    <input type="text" id="contact_person_procurement_mobile_1" class="form-control" > 
                                </div>

                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Mobile 2</label>
                                <div class="col-md-4">
                                    <input type="text" id="contact_person_procurement_mobile_2" class="form-control" >
                                </div>

                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput"><h4>Accounting</h4></label>
                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Name</label>
                                <div class="col-md-10">
                                    <input type="text" id="contact_person_account_name" class="form-control" >
                                </div>
                            </div>

                            <!-- Text input-->
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Telephone No.</label>
                                <div class="col-md-10">
                                    <input type="text" id="contact_person_account_telephone" class="form-control" >
                                </div>
                            </div>

                            <!-- Text input-->
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Fax no.</label>
                                <div class="col-md-10">
                                    <input type="text" id="contact_person_account_fax" class="form-control" >
                                </div>
                            </div>

                            <!-- Text input-->
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Email</label>
                                <div class="col-md-4">
                                    <input type="text" id="contact_person_account_email" class="form-control" >
                                </div>


                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Mobile 1</label>
                                <div class="col-md-4">
                                    <input type="text" id="contact_person_account_mobile_1" class="form-control" >
                                </div>

                            </div>
                            <div class="form-group">
                                <label class="col-md-2 control-label" for="textinput">Mobile 2</label>
                                <div class="col-md-4">
                                    <input type="text" id="contact_person_account_mobile_2" class="form-control"    >
                                </div>
                            </div>
                        </fieldset>
                    </div>
                    <button class="btn btn-primary nextBtn btn-lg pull-right" type="button" >Next</button>
                </div>
            </div>
        </div>
        <div class="row setup-content" id="step-2">
            <div class="col-xs-12">
                <div class="col-md-12">
                    <div class="form-horizontal" role="form" >
                        <fieldset>
                            <!-- Form Name -->
                            <h4>Branches</h4>
                            <div class="branchhere" id="thisform"> 

                                <div id="clonebranch" class="clonebranchremove_0">
                                    <div class="form-group">
                                        <label class="col-md-2 control-label" for="textinput"> <h4>Branch 1</h4>  </label>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-md-2 control-label" for="textinput"> Contact Person </label>
                                        <div class="col-md-10">
                                            <input  type="text" id="branches_contact_person_0" class="form-control">
                                        </div>
                                    </div>


                                    <div class="form-group">
                                        <label class="col-md-2 control-label" for="textinput"> Address</label>
                                        <div class="col-md-10">
                                            <input   type="text" id="branches_address_0" class="form-control">
                                        </div>
                                    </div>


                                    <div class="form-group">
                                        <label class="col-md-2 control-label" for="textinput"> City/Municpality</label>
                                        <div class="col-md-10">
                                            <input type="text" id="branches_city_municipality_0" class="form-control">
                                        </div>
                                    </div>


                                    <div class="form-group">
                                        <label class="col-md-2 control-label" for="textinput"> Province</label>
                                        <div class="col-md-4">
                                            <input type="text" id="branches_province_0" class="form-control">
                                        </div>

                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-2 control-label" for="textinput"> Region</label>
                                        <div class="col-md-10">
                                            <input type="text" id="branches_region_0" class="form-control">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-md-2 control-label" for="textinput"> Zip Code</label>
                                        <div class="col-md-10">
                                            <input type="text" id="branches_zip_0" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-2 control-label" for="textinput"> Telephone no.</label>
                                        <div class="col-md-10">
                                            <input type="text" id="branches_telephone_0" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-2 control-label" for="textinput"> Fax no.</label>
                                        <div class="col-md-10">
                                            <input type="text" id="branches_fax_0" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-2 control-label" for="textinput"> Email</label>
                                        <div class="col-md-10">
                                            <input type="text" id="branches_email_0" class="form-control">
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </fieldset>
                    </div>
                    <input type="hidden" id="hook" value="0" />
                    <button class="btn btn-primary btn-small col-lg-6" id="add_branches">Add More Branches</button>
                    <button class="btn btn-danger col-lg-6" id="remove_branches">Remove</button>
                    <button class="btn btn-primary nextBtn btn-lg pull-right" type="button" >Next</button>
                </div>
            </div>
        </div>
        <div class="row setup-content" id="step-3">
            <div class="col-xs-12">
                <div class="col-md-12">

                    <div class="form-horizontal" role="form">
                        <fieldset>
                            <!-- Form Name -->
                            <h4>Mechanical</h4>
                            <!-- Text input-->
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Pumps, Fans and Blowers </label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Automotive and heavy equipments and parts </label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Conveyors, pulleys, conveyor belts, rollers, sheaves, belts, chain, sprockets, speed reducers, coupling</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Lubricants, grease, engine oil, hydraulic oil, transmission oils</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Gasket, oil seal, mechanical seal, packing, bush </label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Heating, Cooling, Ventilating, Air Conditioning and Refrigeration quipment and parts </label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" />Pneumatics and Hydraulics equipment and parts </label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Pipes, Tubes, Valves and other piping components </label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Bearings (roller, thrust, plummer, pillow block) </label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Power tools,machine shop,fabrication and welding equipments,tools and consumables</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Engineering materials </label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Adhesive, Sealants, Solvents, and Removers </label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" />Internal combustion engines, parts, and accessories</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Boiler and HRSG components and pressure parts </label>
                            </div>

                        </fieldset>
                    </div>
                    <div class="form-horizontal" role="form">
                        <fieldset>
                            <!-- Form Name -->
                            <h4>Electrical</h4>
                            <!-- Text input-->
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Circuit breakers, power supply, contactors, relays, timer, switch, transducers</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Transformers, fuses, capacitors, resistors, surge suppressor, UPS system, panels </label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Lighting (CFL, LED, HID, incandescent), lighting controls, ballast, batteries and fixtures</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Induction motors, gearmotors, definite and general purpose motors and HVAC motors</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Induction motors, gearmotors, definite and general purpose motors and HVAC motors </label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Wires and cables, connectors, terminal lugs, fittings, fasteners, receptacle and panels</label>
                            </div>
                        </fieldset>
                    </div>
                    <div class="form-horizontal" role="form">
                        <fieldset>
                            <!-- Form Name -->
                            <h4>Instrumentation</h4>
                            <!-- Text input-->
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Meters, Gauges, Transmitters and other measuring equipments</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Laboratory testing, measuring and analyzing equipments </label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Medical testing, measuring and analyzing equipments</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Controls, automation and monitoring systems and equipments</label>
                            </div>
                        </fieldset>
                    </div>
                    <div class="form-horizontal" role="form">
                        <fieldset>
                            <!-- Form Name -->
                            <h4>Construction</h4>
                            <!-- Text input-->
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Construction and other hardware materials</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Prefabricated walls, precast concrete, hardiflex, precast post and beams </label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Roofing materials</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Plumbing and piping materials</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Painting and finishing materials</label>
                            </div>
                        </fieldset>
                    </div>
                    <div class="form-horizontal" role="form">
                        <fieldset>
                            <!-- Form Name -->
                            <h4>Chemicals</h4>
                            <!-- Text input-->
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Pesticide, Fertilizers, Herbicides, and other agrochemicals</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Water and waste treatment chemicals </label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Cleaning and sanitation chemicals</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Compressed gases and specialty gases</label>
                            </div>
                        </fieldset>
                    </div>
                    <div class="form-horizontal" role="form">
                        <fieldset>
                            <!-- Form Name -->
                            <h4>Safety and Security</h4>
                            <!-- Text input-->
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Personal Protection Equipment and kits</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Electronic Access Devices, CCTV, security surveilance and detection equipments</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Fire and smoke detection and alarm equipments and parts</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> First aid, emergency and rescue equipments and kits</label>
                            </div>
                        </fieldset>
                    </div>
                    <div class="form-horizontal" role="form">
                        <fieldset>
                            <!-- Form Name -->
                            <h4>Storage and Cleaning</h4>
                            <!-- Text input-->
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Storage racks, shelves, bin, cabinets, and baskets</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Pallets, skids, guard rails, labels and signages</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Forklift, cranes, pallet trucks, lift trucks and other material handling equipments</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Facilities cleaning and maintenance</label>
                            </div>
                        </fieldset>
                    </div>
                    <div class="form-horizontal" role="form">
                        <fieldset>
                            <!-- Form Name -->
                            <h4>Electronics</h4>
                            <!-- Text input-->
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Computers, monitors,speakers, printers and other office equipments</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Electronic communication devices</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Consumer Electronics</label>
                            </div>

                        </fieldset>
                    </div>
                    <div class="form-horizontal" role="form">
                        <fieldset>
                            <!-- Form Name -->
                            <h4>Home</h4>
                            <!-- Text input-->
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Towels, blankets, mattresses, textile and clothing</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Kitchen and dining wares</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Furnitures and decors</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Home Appliances</label>
                            </div>

                        </fieldset>
                    </div>
                    <div class="form-horizontal" role="form">
                        <fieldset>
                            <!-- Form Name -->
                            <h4>Agriculture</h4>
                            <!-- Text input-->
                            <div class="form-group">
                                <div class="col-xs-1"></div>   <label class="col-md-7 " for="textinput"><input type="checkbox" /> Fruits</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Vegetables and spices</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Livestock and meat</label>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-1"></div>  <label class="col-md-7 " for="textinput"><input type="checkbox" /> Tractors and other agricultural equipments, machines and tools</label>
                            </div>

                        </fieldset>
                    </div>
                    <div class="form-group">
                        <h3>Other Services</h3>
                        <!--<label class="col-md-2 control-label" for="textinput">Other Services</label>-->
                        <!--                        <div class="col-md-10 here">
                                                    <div id="clonethis" class="clonediv"><input type="text" id="other_services" class="form-control clear"> <br/></div> 
                                                </div>
                                                <div class="col-md-2"></div><button class="btn btn-primary btn-small" id="add_services">Add</button>
                                                <div class="col-md-2"></div> <button class="btn btn-danger" id="remove_services">x</button>-->
                        <div class="form-horizontal" role="form" >
                            <fieldset>
                                <!-- Form Name -->
                               
                                <div class="serviceshere" id="thisform"> 
                                    <div id="cloneservices" class="cloneservicesremove_0">
                                        <div class="form-group">
                                            <label class="col-md-2 control-label" for="textinput"> Other Services </label>
                                            <div class="col-md-10">
                                                <input  type="text" id="other_services_0" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        </div>
                        <input type="hidden" id="hookservices" value="0" />
                        <button class="btn btn-primary btn-small col-lg-6" id="add_services">Add More Services</button>
                        <button class="btn btn-danger col-lg-6" id="remove_services">Remove</button>
                    </div>
                    <button class="btn btn-success btn-lg pull-right" type="submit">Finish!</button>
                </div>
            </div>
        </div>
    </form>
</div>
</body>
<style type="text/css">
    body{ 
        margin-top:40px; 
    }

    .stepwizard-step p {
        margin-top: 10px;
    }

    .stepwizard-row {
        display: table-row;
    }

    .stepwizard {
        display: table;
        width: 100%;
        position: relative;
    }

    .stepwizard-step button[disabled] {
        opacity: 1 !important;
        filter: alpha(opacity=100) !important;
    }

    .stepwizard-row:before {
        top: 14px;
        bottom: 0;
        position: absolute;
        content: " ";
        width: 100%;
        height: 1px;
        background-color: #ccc;
        z-order: 0;

    }

    .stepwizard-step {
        display: table-cell;
        text-align: center;
        position: relative;
    }

    .btn-circle {
        width: 30px;
        height: 30px;
        text-align: center;
        padding: 6px 0;
        font-size: 12px;
        line-height: 1.428571429;
        border-radius: 15px;
    }
</style>
<script type="text/javascript">
    $(document).ready(function() {

        var navListItems = $('div.setup-panel div a'),
                allWells = $('.setup-content'),
                allNextBtn = $('.nextBtn');

        allWells.hide();

        navListItems.click(function(e) {
            e.preventDefault();
            var $target = $($(this).attr('href')),
                    $item = $(this);

            if (!$item.hasClass('disabled')) {
                navListItems.removeClass('btn-primary').addClass('btn-default');
                $item.addClass('btn-primary');
                allWells.hide();
                $target.show();
                $target.find('input:eq(0)').focus();
            }
        });

        allNextBtn.click(function() {
            var curStep = $(this).closest(".setup-content"),
                    curStepBtn = curStep.attr("id"),
                    nextStepWizard = $('div.setup-panel div a[href="#' + curStepBtn + '"]').parent().next().children("a"),
                    curInputs = curStep.find("input[type='text'],input[type='url']"),
                    isValid = true;

            $(".form-group").removeClass("has-error");
            for (var i = 0; i < curInputs.length; i++) {
                if (!curInputs[i].validity.valid) {
                    isValid = false;
                    $(curInputs[i]).closest(".form-group").addClass("has-error");
                }
            }

            if (isValid)
                nextStepWizard.removeAttr('disabled').trigger('click');
        });

        $('div.setup-panel div a.btn-primary').trigger('click');
    });
</script>
<script type="text/javascript" src="<?php echo base_url('public/add_other_services_button.js'); ?>"></script>
</html>